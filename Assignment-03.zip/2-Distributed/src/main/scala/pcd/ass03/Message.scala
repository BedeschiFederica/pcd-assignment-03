package pcd.ass03

/** Tag interface for all messages sends by actors */
trait Message
